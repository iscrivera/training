def create_cast_list(filename):
    cast_list = []
    # usar with para abrir el archivo
    # use el bucle for para procesar cada línea
    # agregar el nombre del actor a la lista cast_list

    return cast_list

# no modificar este bloque del código
# ajustar solo la ruta del archivo si es necesario
cast_list = create_cast_list('data_files/flying_circus_cast.txt')
for actor in cast_list:
    print(actor)
