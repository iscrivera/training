names =  # obtener la lista de nombres de alumnos
assignments =  # obtener la lista de número de asignaciones
grades =  # obtener la lista de calificaciones

# cadena de mensaje a ser usada para cada estudiante
# NOTA: use .format() con esta cadena en el bucle for
message = "Hi {},\n\nThis is a reminder that you have {} assignments left to \
submit before you can graduate. You're current grade is {} and can increase \
to {} if you submit all assignments before the due date.\n\n"

# escriba su código usando un bucle for que itere sobre las listas de nombres, asignaciones y calificaciones
